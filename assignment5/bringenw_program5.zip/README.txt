To compile using gcc, run the following command:
gcc -pthread -o line_processor line_processor.c