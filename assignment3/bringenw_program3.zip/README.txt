to compile using gcc, run the following command:
gcc main.c -o smallsh