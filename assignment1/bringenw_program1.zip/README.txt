compile by running the following command:
    gcc assignment1.c movie.c -o assignment1