compile using make or by running the command:
    gcc -std=gnu99 -o movies assignment1.c movie.c